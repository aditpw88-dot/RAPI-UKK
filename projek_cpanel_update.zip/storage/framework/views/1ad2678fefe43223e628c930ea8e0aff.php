<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <p class="text-xs font-semibold uppercase tracking-wider text-amber-700">Panel PIC Ruang</p>
            <h2 class="mt-1 text-2xl font-bold text-slate-900">Manajemen Ruang</h2>
            <p class="mt-0.5 text-xs text-slate-500">Pantau ketersediaan, kapasitas, dan identitas ruangan di bawah tanggung jawab Anda.</p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-gray-100 px-4 py-6 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-7xl space-y-6">
            <?php if(session('success')): ?>
                <div class="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800 shadow-2xs"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 shadow-2xs"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-xl font-bold text-slate-900">Daftar Ruangan</h3>
                    <p class="text-xs text-slate-500">
                        <?php if($rooms->total() > 0): ?>
                            Menampilkan <?php echo e($rooms->firstItem()); ?>–<?php echo e($rooms->lastItem()); ?> dari <?php echo e($rooms->total()); ?> ruangan (Urut: Ruang Wijaya, DAK, Lab 1–21, Ruang 1–seterusnya).
                        <?php else: ?>
                            Tidak ada data ruangan.
                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <!-- Form Pencarian & Filter Status -->
            <form method="GET" action="<?php echo e(route('pic.rooms')); ?>" class="grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:grid-cols-[1fr_12rem_auto_auto]">
                <div class="relative">
                    <input 
                        type="search" 
                        name="search" 
                        value="<?php echo e(request('search')); ?>" 
                        placeholder="Cari nama ruang..." 
                        aria-label="Cari nama ruang" 
                        class="w-full rounded-lg border-gray-300 py-2 pl-9 pr-3 text-sm font-medium focus:border-slate-800 focus:ring-1 focus:ring-slate-800"
                    >
                    <svg class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
                <select name="active" aria-label="Filter status ruang" class="rounded-lg border-gray-300 text-sm font-medium focus:border-slate-800 focus:ring-1 focus:ring-slate-800">
                    <option value="">Semua status</option>
                    <option value="active" <?php if(request('active') === 'active'): echo 'selected'; endif; ?>>Aktif</option>
                    <option value="inactive" <?php if(request('active') === 'inactive'): echo 'selected'; endif; ?>>Tidak aktif</option>
                </select>
                <button type="submit" class="rounded-lg bg-slate-900 px-5 py-2 text-sm font-semibold text-white shadow-2xs transition hover:bg-slate-700">Cari / Filter</button>
                <a href="<?php echo e(route('pic.rooms')); ?>" class="rounded-lg border border-gray-300 px-4 py-2 text-center text-sm font-semibold text-slate-700 transition hover:bg-gray-50">Reset</a>
            </form>

            <!-- Tabel Daftar Ruang -->
            <section class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50/80 text-xs uppercase tracking-wider text-slate-500 border-b border-gray-200">
                            <tr>
                                <th scope="col" class="px-6 py-4 font-bold">Ruangan</th>
                                <th scope="col" class="px-6 py-4 font-bold">Kapasitas</th>
                                <th scope="col" class="px-6 py-4 font-bold">Status</th>
                                <th scope="col" class="px-6 py-4 text-right font-bold">Identitas &amp; Detail</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 bg-white">
                            <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="align-top hover:bg-slate-50/70 transition-colors">
                                    <td class="px-6 py-4">
                                        <p class="text-base font-bold text-slate-900"><?php echo e($room->room_name); ?></p>
                                    </td>
                                    <td class="px-6 py-4 text-slate-700">
                                        <span class="inline-flex items-center gap-1.5 font-medium text-sm">
                                            <svg width="16" height="16" class="text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                            </svg>
                                            <span><?php echo e($room->capacity); ?> orang</span>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php if($room->is_active): ?>
                                            <span class="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-800">
                                                <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                                <span>Aktif</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
                                                <span class="h-1.5 w-1.5 rounded-full bg-slate-400"></span>
                                                <span>Tidak aktif</span>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <details class="group inline-block text-left">
                                            <summary class="flex w-fit ml-auto cursor-pointer list-none items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-2xs transition hover:border-slate-500 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-400 [&::-webkit-details-marker]:hidden">
                                                <span class="text-slate-400 transition group-open:rotate-90" aria-hidden="true">▸</span>
                                                <span>Lihat Identitas Ruangan</span>
                                            </summary>
                                            <div class="mt-2.5 w-80 rounded-xl border border-slate-200 bg-slate-50 p-4 text-left shadow-lg ring-1 ring-black/5">
                                                <p class="font-bold text-slate-900 text-sm border-b border-slate-200 pb-2 mb-2">
                                                    <?php echo e($room->room_name); ?>

                                                </p>
                                                <div class="space-y-2 text-xs text-slate-700">
                                                    <p><span class="font-semibold text-slate-900">Kapasitas:</span> <?php echo e($room->capacity); ?> orang</p>
                                                    <p><span class="font-semibold text-slate-900">Status Operasional:</span> <?php echo e($room->is_active ? 'Aktif' : 'Tidak aktif'); ?></p>
                                                    <div>
                                                        <p class="font-semibold text-slate-900 mb-1">Penanggung Jawab (PIC):</p>
                                                        <?php if($room->all_pics->isNotEmpty()): ?>
                                                            <ul class="space-y-1.5 pl-2.5 border-l-2 border-slate-300">
                                                                <?php $__currentLoopData = $room->all_pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <span class="font-semibold text-slate-900">• <?php echo e($pic->fullname); ?></span>
                                                                        <span class="text-[11px] text-slate-500 block ml-2">WA: <?php echo e($pic->phone_number ?: 'Belum diisi'); ?> &bull; <?php echo e($pic->email); ?></span>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php else: ?>
                                                            <p class="text-slate-400 italic">Belum ada PIC ditugaskan</p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </details>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-12 text-center text-sm text-slate-500">
                                        Tidak ada data ruangan yang cocok dengan filter.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if($rooms->hasPages()): ?>
                    <div class="border-t border-gray-200 px-6 py-4 bg-white">
                        <?php echo e($rooms->links()); ?>

                    </div>
                <?php endif; ?>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\UKK-aditya\resources\views\pic\rooms\index.blade.php ENDPATH**/ ?>