<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['startDate', 'endDate' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['startDate', 'endDate' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $start = \Illuminate\Support\Carbon::parse($startDate);
    $end = $endDate ? \Illuminate\Support\Carbon::parse($endDate) : $start;
?>

<?php echo e($start->format('d/m/Y')); ?><?php if($start->toDateString() !== $end->toDateString()): ?> – <?php echo e($end->format('d/m/Y')); ?><?php endif; ?>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views/components/event-date-range.blade.php ENDPATH**/ ?>