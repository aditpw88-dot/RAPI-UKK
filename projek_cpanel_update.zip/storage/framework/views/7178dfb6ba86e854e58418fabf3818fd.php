<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'font-sans antialiased',
        'admin-theme' => auth()->check() && (
            str_contains(strtolower(auth()->user()->role?->role_name ?? ''), 'admin')
            || str_contains(strtolower(auth()->user()->role?->role_name ?? ''), 'waka')
            || str_contains(strtolower(auth()->user()->role?->role_name ?? ''), 'guru')
            || str_contains(strtolower(auth()->user()->role?->role_name ?? ''), 'pic')
        ),
    ]); ?>">
        <div x-data="{ sidebarOpen: true }" class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="flex min-h-screen flex-col transition-all duration-300" :class="sidebarOpen ? 'lg:pl-64' : 'lg:pl-20'">
                <!-- Page Heading -->
                <?php if(isset($header)): ?>
                    <header class="bg-white shadow">
                        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                            <?php echo e($header); ?>

                        </div>
                    </header>
                <?php endif; ?>

                <!-- Page Content -->
                <main class="flex-1">
                    <?php if(isset($slot)): ?>
                        <?php echo e($slot); ?>

                    <?php else: ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    <?php endif; ?>
                </main>
                <?php if (isset($component)) { $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $attributes = $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $component = $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
            </div>
        </div>
        <dialog id="action-confirmation" class="w-[min(92vw,30rem)] rounded-xl border border-gray-200 bg-white p-0 text-slate-900 shadow-2xl backdrop:bg-slate-950/60 backdrop:backdrop-blur-md">
            <div class="border-b border-gray-200 px-6 py-4">
                <p id="action-confirmation-eyebrow" class="text-xs font-semibold uppercase tracking-widest text-slate-500">Konfirmasi tindakan</p>
                <h2 id="action-confirmation-title" class="mt-1 text-lg font-semibold">Lanjutkan?</h2>
            </div>
            <div class="space-y-2 px-6 py-5">
                <p id="action-confirmation-message" class="text-sm leading-6 text-slate-600"></p>
                <p id="action-confirmation-item" class="rounded-md bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-800"></p>
                <p class="text-xs text-slate-500">Periksa kembali sebelum melanjutkan. Tindakan ini baru dijalankan setelah Anda mengonfirmasi.</p>
            </div>
            <div class="flex justify-end gap-3 border-t border-gray-200 bg-gray-50 px-6 py-4">
                <button type="button" id="action-confirmation-cancel" class="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-gray-100">Batal</button>
                <button type="button" id="action-confirmation-continue" class="rounded-md bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700">Lanjutkan</button>
            </div>
        </dialog>
    </body>
</html>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views/layouts/app.blade.php ENDPATH**/ ?>