<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <p class="text-sm font-medium text-slate-500">Administrasi Sistem</p>
            <h2 class="mt-1 text-2xl font-semibold text-slate-900">Dashboard Admin</h2>
            <p class="mt-1 text-sm text-slate-500">Pantau ruang, agenda, dan laporan kerusakan sekolah.</p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-gray-100 px-4 py-8 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-7xl space-y-6">
            <?php if(session('success')): ?>
                <div class="rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="admin-stat-grid grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <?php $__currentLoopData = [['Total User', $statistics['users'], 'users'], ['Total Ruang', $statistics['rooms'], 'admin.rooms'], ['Agenda', $statistics['events'], 'admin.events'], ['Kerusakan Terbuka', $statistics['open_complaints'], 'admin.complaints']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $route]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($route === 'users' ? route('users.index') : route($route)); ?>" class="admin-stat-card rounded-xl border border-gray-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
                        <p class="admin-stat-label text-sm"><?php echo e($label); ?></p>
                        <p class="admin-stat-value mt-2 text-3xl font-bold"><?php echo e($value); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <a href="<?php echo e(route('admin.rooms')); ?>" class="admin-management-card rounded-xl p-5 text-white shadow-sm"><p class="text-lg font-semibold">Manajemen Ruang</p><p class="mt-1 text-sm"><?php echo e($statistics['active_rooms']); ?> ruang aktif</p></a>
                <a href="<?php echo e(route('admin.events')); ?>" class="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200 hover:ring-slate-400"><p class="text-lg font-semibold text-slate-900">Manajemen Agenda</p><p class="mt-1 text-sm text-slate-500"><?php echo e($statistics['pending_events']); ?> agenda menunggu persetujuan</p></a>
                <a href="<?php echo e(route('admin.complaints')); ?>" class="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200 hover:ring-slate-400"><p class="text-lg font-semibold text-slate-900">Manajemen Kerusakan</p><p class="mt-1 text-sm text-slate-500"><?php echo e($statistics['complaints']); ?> laporan tercatat</p></a>
            </div>

            <div class="grid gap-6 lg:grid-cols-3">
                <div class="grid content-start gap-6 sm:grid-cols-2 lg:col-span-2">
                    <section class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                        <div class="flex items-center justify-between border-b border-gray-200 px-5 py-4"><h3 class="font-semibold text-slate-900">Agenda Terbaru</h3><a href="<?php echo e(route('admin.events')); ?>" class="text-xs font-semibold text-slate-600 hover:text-slate-900">Lihat semua</a></div>
                        <div class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $latestEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="px-5 py-4"><p class="font-medium text-slate-900"><?php echo e($event->event_name); ?></p><p class="mt-1 text-xs text-slate-500"><?php echo e($event->room_names ?: '-'); ?> · <?php if (isset($component)) { $__componentOriginaleb3dbf8df038dcf14b501b275017aee2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-date-range','data' => ['startDate' => $event->date,'endDate' => $event->end_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['start-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->date),'end-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->end_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $attributes = $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $component = $__componentOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?> · <?php echo e($event->lifecycle_status_label); ?></p></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p class="px-5 py-8 text-sm text-slate-500">Belum ada agenda.</p> <?php endif; ?>
                        </div>
                    </section>
                    <section class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                        <div class="flex items-center justify-between border-b border-gray-200 px-5 py-4"><h3 class="font-semibold text-slate-900">Kerusakan Terbaru</h3><a href="<?php echo e(route('admin.complaints')); ?>" class="text-xs font-semibold text-slate-600 hover:text-slate-900">Lihat semua</a></div>
                        <div class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $latestComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="px-5 py-4"><p class="font-medium text-slate-900"><?php echo e($complaint->room?->room_name ?? '-'); ?></p><p class="mt-1 text-xs text-slate-500"><?php echo e(\Illuminate\Support\Str::limit($complaint->description, 80)); ?> · <?php echo e($complaint->status_repair); ?></p><p class="mt-1 text-xs text-slate-600">Pelapor: <?php echo e($complaint->reporter?->fullname ?? '-'); ?> · <?php echo e($complaint->reporter?->username ?? '-'); ?> · <?php echo e($complaint->reporter?->role?->role_name ?? '-'); ?></p><p class="text-xs text-slate-500"><?php echo e($complaint->reporter?->email ?? '-'); ?> · <?php echo e($complaint->reporter?->phone_number ?: '-'); ?></p></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p class="px-5 py-8 text-sm text-slate-500">Belum ada laporan kerusakan.</p> <?php endif; ?>
                        </div>
                    </section>
                </div>

                <aside class="h-fit rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <h3 class="font-semibold text-slate-900">Akses Cepat</h3>
                    <p class="mt-1 text-sm text-slate-500">Pilih tindakan yang ingin dilakukan.</p>
                    <div class="mt-4 space-y-3">
                        <a href="<?php echo e(route('admin.events.create')); ?>" class="group flex items-center justify-between rounded-lg border border-slate-200 p-4 transition hover:border-slate-400 hover:bg-slate-50">
                            <span>
                                <span class="block font-semibold text-slate-900">Peminjaman Ruang</span>
                                <span class="mt-1 block text-xs text-slate-500">Buat pengajuan pemakaian ruang</span>
                            </span>
                            <span aria-hidden="true" class="text-lg text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-700">→</span>
                        </a>
                        <a href="<?php echo e(route('admin.complaints.create')); ?>" class="group flex items-center justify-between rounded-lg border border-slate-200 p-4 transition hover:border-slate-400 hover:bg-slate-50">
                            <span>
                                <span class="block font-semibold text-slate-900">Pengaduan Cepat</span>
                                <span class="mt-1 block text-xs text-slate-500">Laporkan kerusakan ruang</span>
                            </span>
                            <span aria-hidden="true" class="text-lg text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-700">→</span>
                        </a>
                        <a href="<?php echo e(route('admin.rooms')); ?>" class="group flex items-center justify-between rounded-lg border border-slate-200 p-4 transition hover:border-slate-400 hover:bg-slate-50">
                            <span>
                                <span class="block font-semibold text-slate-900">Daftar Ruang</span>
                                <span class="mt-1 block text-xs text-slate-500">Lihat dan kelola ruang sekolah</span>
                            </span>
                            <span aria-hidden="true" class="text-lg text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-700">→</span>
                        </a>
                        <a href="<?php echo e(route('users.index', ['create' => 1])); ?>" class="group flex items-center justify-between rounded-lg border border-slate-200 p-4 transition hover:border-slate-400 hover:bg-slate-50">
                            <span>
                                <span class="block font-semibold text-slate-900">Tambah User</span>
                                <span class="mt-1 block text-xs text-slate-500">Daftarkan akun pengguna baru</span>
                            </span>
                            <span aria-hidden="true" class="text-lg text-slate-400 transition group-hover:translate-x-1 group-hover:text-slate-700">→</span>
                        </a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views\dashboard.blade.php ENDPATH**/ ?>