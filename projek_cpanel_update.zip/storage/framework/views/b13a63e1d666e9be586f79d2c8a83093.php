<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['compact' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['compact' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $start = date('H:i', strtotime($startTime));
    $end = date('H:i', strtotime($endTime));
    $sessions = collect(config('schedule.sessions'));
    $startSession = $sessions->search(fn ($times) => $times['start_time'] === $start);
    $endSession = $sessions->search(fn ($times) => $times['end_time'] === $end);
?>

<div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['space-y-1' => ! $compact, 'space-y-1 whitespace-nowrap' => $compact]); ?>">
    <?php if($startSession !== false && $endSession !== false): ?>
        <?php if($compact): ?>
            <p class="font-semibold text-slate-800">
                Sesi <?php echo e($startSession); ?><?php echo e($startSession !== $endSession ? '–' . $endSession : ''); ?>

            </p>
        <?php else: ?>
            <p class="font-semibold">
                Sesi <?php echo e($startSession); ?><?php echo e($startSession !== $endSession ? ' - Sesi ' . $endSession : ''); ?>

            </p>
        <?php endif; ?>
    <?php endif; ?>
    <?php if($compact): ?>
        <p class="text-slate-600"><?php echo e($start); ?>–<?php echo e($end); ?></p>
    <?php else: ?>
        <p>Mulai: <?php echo e($start); ?></p>
        <p>Selesai: <?php echo e($end); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views\components\event-time.blade.php ENDPATH**/ ?>