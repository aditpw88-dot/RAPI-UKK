<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan <?php echo e(match ($period['type']) { 'daily' => 'Harian', 'weekly' => 'Mingguan', default => 'Bulanan' }); ?> <?php echo e($period['label']); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; color: #292524; font-size: 10px; }
        h1 { font-size: 20px; margin: 0 0 6px; color: #171513; }
        h2 { font-size: 14px; margin: 18px 0 8px; }
        p { margin: 4px 0; color: #57534e; }
        body > p:first-child { color: #b45309; }
        .summary { width: 100%; margin: 14px 0; }
        .summary td { width: 33.333%; padding: 9px; background: #faf6ef; border: 1px solid #e7ddd0; }
        .summary strong { display: block; margin-top: 5px; font-size: 16px; }
        .summary td:last-child strong { color: #b45309; }
        table.data { width: 100%; border-collapse: collapse; }
        .data th, .data td { padding: 6px; border: 1px solid #e7ddd0; text-align: left; vertical-align: top; }
        .data th { background: #eee7dc; }
        .applicant-details { font-size: 11px; line-height: 1.45; }
        .footer { margin-top: 18px; border-top: 1px solid #e7ddd0; padding-top: 8px; font-size: 9px; }
    </style>
</head>
<body>
    <p><strong>SISTEM RAPI</strong></p>
    <h1>Laporan <?php echo e(match ($period['type']) { 'daily' => 'Harian', 'weekly' => 'Mingguan', default => 'Bulanan' }); ?> Peminjaman Ruang</h1>
    <p>Periode: <?php echo e($period['label']); ?></p>
    <p>Dicetak pada: <?php echo e(now()->format('d/m/Y H:i')); ?></p>

    <table class="summary">
        <tr>
            <td>Total Peminjaman<strong><?php echo e($events->count()); ?></strong></td>
            <td>Belum Terlaksana<strong><?php echo e($events->where('lifecycle_status', 'upcoming')->count()); ?></strong></td>
            <td>Sedang Terlaksana<strong><?php echo e($events->where('lifecycle_status', 'in_progress')->count()); ?></strong></td>
            <td>Sudah Terlaksana<strong><?php echo e($events->where('lifecycle_status', 'completed')->count()); ?></strong></td>
        </tr>
    </table>

    <h2>Daftar Peminjaman Ruang</h2>
    <table class="data">
        <thead><tr><th>Tanggal</th><th>Agenda</th><th>Ruang</th><th>Pengaju</th><th>Waktu</th><th>Status</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php if (isset($component)) { $__componentOriginaleb3dbf8df038dcf14b501b275017aee2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-date-range','data' => ['startDate' => $event->date,'endDate' => $event->end_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['start-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->date),'end-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->end_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $attributes = $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $component = $__componentOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?></td>
                    <td><?php echo e($event->event_name); ?></td>
                    <td><?php echo e($event->room_names ?: '-'); ?></td>
                    <td>
                        <?php if($event->pic): ?>
                            <strong><?php echo e($event->pic->fullname); ?></strong><br>
                            <span class="applicant-details">
                                Username: <?php echo e($event->pic->username); ?><br>
                                Peran: <?php echo e($event->pic->role?->role_name ?? '-'); ?><br>
                                Email: <?php echo e($event->pic->email); ?><br>
                                Telepon: <?php echo e($event->pic->phone_number ?: '-'); ?>

                            </span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(substr($event->start_time, 0, 5)); ?> - <?php echo e(substr($event->end_time, 0, 5)); ?></td>
                    <td><?php echo e($event->lifecycle_status_label); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Tidak ada peminjaman pada periode ini.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <p class="footer">Dokumen laporan periode Sistem RAPI.</p>
</body>
</html>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views\reports\monthly-pdf.blade.php ENDPATH**/ ?>