<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <style>
            .calendar-site-header {
                border-bottom: 3px solid #c96a1b;
                background: linear-gradient(110deg, #211c18, #3b2b1b);
                box-shadow: 0 2px 8px rgb(48 35 25 / 18%);
                width: 100%;
            }

            .calendar-site-header-inner {
                box-sizing: border-box;
                display: flex;
                width: 100%;
                max-width: 100%;
                min-height: 76px;
                align-items: center;
                justify-content: space-between;
                margin: 0;
                padding: 14px 36px;
            }

            .calendar-site-title {
                color: #fffaf0;
                font-size: 1.65rem;
                font-weight: 800;
                letter-spacing: 0.02em;
                text-decoration: none;
                transition: color 150ms ease;
            }

            .calendar-site-title:hover {
                color: #f5c27a;
            }

            .calendar-login-button {
                display: inline-flex;
                min-width: 112px;
                min-height: 46px;
                box-sizing: border-box;
                align-items: center;
                justify-content: center;
                border: 2px solid #f5c27a;
                border-radius: 9px;
                padding: 10px 24px;
                background: #c96a1b;
                box-shadow: 0 3px 8px rgb(0 0 0 / 24%);
                color: #ffffff;
                font-size: 1.05rem;
                font-weight: 700;
                text-decoration: none;
                transition: background-color 150ms ease, transform 150ms ease;
            }

            .calendar-login-button:hover {
                transform: translateY(-1px);
                background: #a84e0b;
                color: #ffffff;
            }

            @media (max-width: 640px) {
                .calendar-site-header-inner {
                    padding-right: 16px;
                    padding-left: 16px;
                }

                .calendar-site-title {
                    font-size: 1.25rem;
                }

                .calendar-login-button {
                    min-width: 86px;
                    min-height: 40px;
                    padding: 8px 16px;
                    font-size: 0.95rem;
                }
            }
        </style>
    </head>
    <body class="flex min-h-screen flex-col bg-white text-stone-900">
        <header class="calendar-site-header">
            <div class="calendar-site-header-inner">
                <a href="<?php echo e(route('calendar')); ?>" class="calendar-site-title">Kalender Sekolah</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="calendar-login-button">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="calendar-login-button">Login</a>
                <?php endif; ?>
            </div>
        </header>

        <main class="flex-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php if (isset($component)) { $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $attributes = $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $component = $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
    </body>
</html><?php /**PATH C:\laragon\www\UKK-aditya\resources\views/layouts/calendar.blade.php ENDPATH**/ ?>