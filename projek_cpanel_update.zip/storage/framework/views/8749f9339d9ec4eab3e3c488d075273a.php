<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <p class="text-xs font-semibold uppercase tracking-wider text-amber-700">Panel PIC Ruang</p>
            <h2 class="mt-1 text-2xl font-bold text-slate-900">Manajemen Agenda PIC</h2>
            <p class="mt-0.5 text-xs text-slate-500">Pantau agenda yang sedang dan sudah terlaksana, serta agenda yang ditolak di ruang tanggung jawab Anda.</p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="min-h-screen bg-gray-100 px-4 py-8 sm:px-6 lg:px-8">
        <div class="mx-auto max-w-7xl space-y-6">
            <?php if(session('success')): ?>
                <div class="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800 shadow-2xs"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 shadow-2xs"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <?php if(session('warning')): ?>
                <div class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800 shadow-2xs"><?php echo e(session('warning')); ?></div>
            <?php endif; ?>

            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 class="text-xl font-bold text-slate-900">Daftar Agenda</h3>
                    <p class="text-xs text-slate-500">
                        <?php if($events->total() > 0): ?>
                            Menampilkan <?php echo e($events->firstItem()); ?>–<?php echo e($events->lastItem()); ?> dari <?php echo e($events->total()); ?> agenda di bawah tanggung jawab Anda.
                        <?php else: ?>
                            Daftar agenda di ruang penugasan Anda.
                        <?php endif; ?>
                    </p>
                </div>
            </div>

            <!-- Form Pencarian & Filter Status (Serupa dengan Admin) -->
            <form method="GET" action="<?php echo e(route('pic.events.approved')); ?>" class="grid gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-6">
                <input 
                    type="search" 
                    name="search" 
                    value="<?php echo e(request('search')); ?>" 
                    placeholder="Cari agenda, ruang, pengaju" 
                    aria-label="Cari agenda, ruang, atau pengaju" 
                    class="rounded-lg border-gray-300 text-sm lg:col-span-2 focus:border-slate-800 focus:ring-1 focus:ring-slate-800"
                >
                <select name="status" aria-label="Filter status agenda" class="rounded-lg border-gray-300 text-sm focus:border-slate-800 focus:ring-1 focus:ring-slate-800">
                    <option value="">Semua status</option>
                    <option value="in_progress" <?php if(request('status') === 'in_progress'): echo 'selected'; endif; ?>>Sedang Terlaksana</option>
                    <option value="upcoming" <?php if(request('status') === 'upcoming'): echo 'selected'; endif; ?>>Belum Terlaksana</option>
                    <option value="completed" <?php if(request('status') === 'completed'): echo 'selected'; endif; ?>>Sudah Terlaksana</option>
                    <option value="rejected" <?php if(request('status') === 'rejected'): echo 'selected'; endif; ?>>Ditolak</option>
                </select>
                <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" aria-label="Tanggal mulai" class="rounded-lg border-gray-300 text-sm focus:border-slate-800 focus:ring-1 focus:ring-slate-800">
                <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" aria-label="Tanggal akhir" class="rounded-lg border-gray-300 text-sm focus:border-slate-800 focus:ring-1 focus:ring-slate-800">
                <div class="flex gap-2">
                    <button type="submit" class="flex-1 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-2xs hover:bg-slate-700 transition">Terapkan</button>
                    <a href="<?php echo e(route('pic.events.approved')); ?>" class="rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-gray-50 transition">Reset</a>
                </div>
            </form>

            <!-- Tabel Terpadu Agenda (Format dan Kerapian Sama Persis dengan Admin) -->
            <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
                <div class="overflow-x-auto min-h-[320px]">
                    <table class="w-full divide-y divide-gray-200 text-left text-sm">
                        <thead class="bg-gray-50/80 text-xs uppercase tracking-wider text-slate-500 border-b border-gray-200">
                            <tr>
                                <th scope="col" class="w-[26%] px-5 py-3.5 font-bold">Agenda</th>
                                <th scope="col" class="w-[16%] px-5 py-3.5 font-bold">Ruang</th>
                                <th scope="col" class="w-[18%] px-5 py-3.5 font-bold">Pengaju</th>
                                <th scope="col" class="w-[24%] px-5 py-3.5 font-bold">Jadwal</th>
                                <th scope="col" class="w-[16%] px-5 py-3.5 font-bold">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 bg-white">
                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="align-middle hover:bg-slate-50/70 transition-colors">
                                    <td class="px-5 py-3.5 align-middle">
                                        <p class="font-semibold text-slate-900 text-sm sm:text-base leading-snug"><?php echo e($event->event_name); ?></p>
                                        <?php if($event->event_type): ?>
                                            <span class="mt-1 inline-block text-[11px] font-medium text-slate-500 uppercase tracking-wide">
                                                <?php echo e(config("event_types.{$event->event_type}.label") ?? ucfirst($event->event_type)); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-3.5 align-middle text-slate-700 font-medium">
                                        <div class="flex items-center gap-1.5">
                                            <svg width="16" height="16" class="text-slate-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                            </svg>
                                            <span class="text-sm font-semibold text-slate-800"><?php echo e($event->room_names ?: '-'); ?></span>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5 align-middle text-slate-700">
                                        <div class="flex items-center gap-2">
                                            <div class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-slate-100 text-xs font-bold text-slate-700 ring-1 ring-slate-200">
                                                <?php echo e(strtoupper(substr($event->pic?->fullname ?? 'U', 0, 1))); ?>

                                            </div>
                                            <div class="truncate max-w-[140px]">
                                                <p class="truncate text-sm font-medium text-slate-900"><?php echo e($event->pic?->fullname ?? '-'); ?></p>
                                                <?php if($event->pic?->email): ?>
                                                    <p class="truncate text-[11px] text-slate-400"><?php echo e($event->pic->email); ?></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5 align-middle">
                                        <div class="space-y-1.5 whitespace-nowrap text-left">
                                            <div class="flex items-center gap-1.5 font-bold text-slate-900 text-sm sm:text-base">
                                                <svg width="17" height="17" style="width:17px;height:17px;min-width:17px;" class="text-amber-700 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                </svg>
                                                <span><?php if (isset($component)) { $__componentOriginaleb3dbf8df038dcf14b501b275017aee2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-date-range','data' => ['startDate' => $event->date,'endDate' => $event->end_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['start-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->date),'end-date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event->end_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $attributes = $__attributesOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__attributesOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2)): ?>
<?php $component = $__componentOriginaleb3dbf8df038dcf14b501b275017aee2; ?>
<?php unset($__componentOriginaleb3dbf8df038dcf14b501b275017aee2); ?>
<?php endif; ?></span>
                                            </div>
                                            <?php
                                                $startFormatted = date('H:i', strtotime($event->start_time));
                                                $endFormatted = date('H:i', strtotime($event->end_time));
                                                $sessionList = collect(config('schedule.sessions'));
                                                $startSessionIndex = $sessionList->search(fn ($t) => $t['start_time'] === $startFormatted);
                                                $endSessionIndex = $sessionList->search(fn ($t) => $t['end_time'] === $endFormatted);
                                            ?>
                                            <?php if($startSessionIndex !== false && $endSessionIndex !== false): ?>
                                                <div>
                                                    <span class="inline-flex items-center rounded-md border border-amber-300 bg-amber-50 px-2.5 py-0.5 text-xs font-bold text-amber-900 shadow-2xs">
                                                        Sesi <?php echo e($startSessionIndex); ?><?php echo e($startSessionIndex !== $endSessionIndex ? '–' . $endSessionIndex : ''); ?>

                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                            <div class="flex items-center gap-1.5 font-mono text-sm sm:text-base font-bold text-slate-900">
                                                <svg width="16" height="16" style="width:16px;height:16px;min-width:16px;" class="text-slate-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                                <span><?php echo e($startFormatted); ?>–<?php echo e($endFormatted); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-5 py-3.5 align-middle whitespace-nowrap">
                                        <?php if($event->status === 'approved'): ?>
                                            <?php if($event->lifecycle_status === 'completed'): ?>
                                                <span class="inline-flex items-center gap-1.5 rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-semibold text-blue-800 shadow-2xs">
                                                    <span class="h-1.5 w-1.5 rounded-full bg-blue-500"></span>
                                                    <span><?php echo e($event->lifecycle_status_label); ?></span>
                                                </span>
                                            <?php elseif($event->lifecycle_status === 'in_progress'): ?>
                                                <span class="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-800 shadow-2xs">
                                                    <span class="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                                    <span><?php echo e($event->lifecycle_status_label); ?></span>
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-800 shadow-2xs">
                                                    <span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                                                    <span><?php echo e($event->lifecycle_status_label); ?></span>
                                                </span>
                                            <?php endif; ?>
                                            <?php if($event->completed_at): ?>
                                                <p class="mt-1 text-[11px] text-slate-400">Selesai <?php echo e($event->completed_at->format('d/m/Y H:i')); ?></p>
                                            <?php endif; ?>
                                            <p class="mt-1 text-xs text-slate-500">
                                                <?php echo e($event->approver && (str_contains(strtolower($event->approver->role?->role_name ?? ''), 'admin') || str_contains(strtolower($event->approver->role?->role_name ?? ''), 'waka')) ? ($event->approved_by === $event->pic_id ? 'Disetujui otomatis (Admin)' : 'Disetujui Admin') : 'Disetujui PIC'); ?>

                                            </p>
                                        <?php elseif($event->status === 'rejected'): ?>
                                            <span class="inline-flex items-center gap-1.5 rounded-full border border-red-200 bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700 shadow-2xs">
                                                <span class="h-1.5 w-1.5 rounded-full bg-red-500"></span>
                                                <span>Ditolak</span>
                                            </span>
                                            <?php if($event->rejection_reason): ?>
                                                <p class="mt-1 max-w-[190px] text-xs text-red-600 break-words font-medium">
                                                    Alasan: <?php echo e($event->rejection_reason); ?>

                                                </p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-5 py-12 text-center text-sm text-slate-500">
                                        Tidak ada data agenda yang sesuai dengan pencarian atau filter yang dipilih.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if($events->hasPages()): ?>
                    <div class="border-t border-gray-200 px-6 py-4 bg-white">
                        <?php echo e($events->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views\pic\approved-events.blade.php ENDPATH**/ ?>