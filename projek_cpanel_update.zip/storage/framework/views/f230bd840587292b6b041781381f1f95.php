<div class="calendar-legend" aria-label="Keterangan warna agenda">
    <?php $__currentLoopData = config('event_types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="calendar-legend-item">
            <span class="calendar-legend-swatch" style="background-color: <?php echo e($type['background']); ?>; border-color: <?php echo e($type['border']); ?>;"></span>
            <?php echo e($type['label']); ?>

        </span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <span class="calendar-legend-item">
        <span class="calendar-legend-swatch" style="background-color: #ffe4e6; border-color: #e11d48;"></span>
        Hari libur nasional / cuti bersama
    </span>
</div>
<?php /**PATH C:\laragon\www\UKK-aditya\resources\views/components/calendar-legend.blade.php ENDPATH**/ ?>